import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FormStateNotifier with ChangeNotifier {
  String _username = '';
  String _password = '';

  FormStateNotifier() {
    _loadFromPrefs();
  }

  String get username => _username;
  String get password => _password;

  bool _isValid = false;
  bool get isValid => _isValid;

  void updateUsername(String value) {
    _username = value;
    _saveToPrefs();
    validate();
  }

  void updatePassword(String value) {
    _password = value;
    _saveToPrefs();
    validate();
  }

  void validate() {
    _isValid = _username.isNotEmpty && _password.isNotEmpty;
    notifyListeners(); // Mover para quando realmente for relevante, como depois de uma operação async
  }

  _saveToPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('username', _username);
    await prefs.setString('password', _password);
    notifyListeners(); // Notifica após salvar
  }

  _loadFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    _username = prefs.getString('username') ?? '';
    _password = prefs.getString('password') ?? '';
    validate(); // Revalida após carregar
    notifyListeners(); // Notifica após carregar
  }
}
