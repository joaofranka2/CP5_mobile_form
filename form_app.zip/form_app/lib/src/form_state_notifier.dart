import 'package:flutter/material.dart';

class FormStateNotifier with ChangeNotifier {
  String _name = '';
  String _email = '';
  String _phone = '';
  String _gender = '';
  String _birthDate = '';
  bool _acceptTerms = false;

  // Getters
  String get name => _name;
  String get email => _email;
  String get phone => _phone;
  String get gender => _gender;
  String get birthDate => _birthDate;
  bool get acceptTerms => _acceptTerms;

  // Setters
  void updateName(String value) {
    _name = value;
    notifyListeners();
  }

  void updateEmail(String value) {
    _email = value;
    notifyListeners();
  }

  void updatePhone(String value) {
    _phone = value;
    notifyListeners();
  }

  void updateGender(String value) {
    _gender = value;
    notifyListeners();
  }

  void updateBirthDate(String value) {
    _birthDate = value;
    notifyListeners();
  }

  void updateAcceptTerms(bool value) {
    _acceptTerms = value;
    notifyListeners();
  }
}
