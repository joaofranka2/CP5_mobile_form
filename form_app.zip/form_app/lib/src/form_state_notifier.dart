import 'package:flutter/material.dart';

class FormStateNotifier with ChangeNotifier {
  String _name = '';
  String _email = '';
  String _address = '';
  String _phone = '';

  // Getters para obter os valores
  String get name => _name;
  String get email => _email;
  String get address => _address;
  String get phone => _phone;

  // Getter para verificar se o formulário é válido
  bool get isValid =>
      _name.isNotEmpty &&
      RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(_email) &&
      _address.isNotEmpty &&
      _phone.length == 11;

  // Atualiza o nome e notifica listeners
  void updateName(String value) {
    _name = value;
    notifyListeners();
  }

  // Atualiza o email e notifica listeners
  void updateEmail(String value) {
    _email = value;
    notifyListeners();
  }

  // Atualiza o endereço e notifica listeners
  void updateAddress(String value) {
    _address = value;
    notifyListeners();
  }

  // Atualiza o telefone e notifica listeners
  void updatePhone(String value) {
    _phone = value;
    notifyListeners();
  }
}
