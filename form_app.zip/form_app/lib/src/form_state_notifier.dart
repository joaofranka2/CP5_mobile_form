import 'package:flutter/material.dart';

class FormStateNotifier with ChangeNotifier {
  String _name = '';
  String _email = '';
  String _address = '';
  String _phone = '';
  String _birthDate = '';
  String _gender = '';
  bool _acceptTerms = false;

  // Getters
  String get name => _name;
  String get email => _email;
  String get address => _address;
  String get phone => _phone;
  String get birthDate => _birthDate;
  String get gender => _gender;
  bool get acceptTerms => _acceptTerms;

  // Setters
  void updateName(String value) {
    _name = value;
    notifyListeners();
  }

  void updateEmail(String value) {
    _email = value;
    notifyListeners();
  }

  void updateAddress(String value) {
    _address = value;
    notifyListeners();
  }

  void updatePhone(String value) {
    _phone = value;
    notifyListeners();
  }

  void updateBirthDate(String value) {
    _birthDate = value;
    notifyListeners();
  }

  void updateGender(String value) {
    _gender = value;
    notifyListeners();
  }

  void updateAcceptTerms(bool value) {
    _acceptTerms = value;
    notifyListeners();
  }
}
