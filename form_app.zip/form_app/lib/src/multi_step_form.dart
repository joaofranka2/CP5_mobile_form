import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../form_state_notifier.dart';

class MultiStepFormDemo extends StatefulWidget {
  const MultiStepFormDemo({super.key});

  @override
  _MultiStepFormDemoState createState() => _MultiStepFormDemoState();
}

class _MultiStepFormDemoState extends State<MultiStepFormDemo> {
  int _currentStep = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Formulário Multi-Etapas')),
      body: Consumer<FormStateNotifier>(
        builder: (context, formState, child) {
          return Stepper(
            currentStep: _currentStep,
            onStepContinue: () {
              if (_currentStep < 5) {
                setState(() => _currentStep += 1);
              } else {
                if (formState.acceptTerms) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Formulário Completo!')),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                        content:
                            Text('Por favor, aceite os termos e condições')),
                  );
                }
              }
            },
            onStepCancel: () {
              if (_currentStep > 0) {
                setState(() => _currentStep -= 1);
              }
            },
            steps: [
              Step(
                title: const Text('Nome'),
                content: TextFormField(
                  initialValue: formState.name,
                  decoration: InputDecoration(
                    labelText: 'Nome',
                    border: OutlineInputBorder(),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: formState.name.isNotEmpty
                            ? Colors.green
                            : Colors.grey,
                      ),
                    ),
                  ),
                  onChanged: (value) => formState.updateName(value),
                ),
                isActive: _currentStep >= 0,
              ),
              Step(
                title: const Text('Email'),
                content: TextFormField(
                  initialValue: formState.email,
                  decoration: InputDecoration(
                    labelText: 'Email',
                    border: OutlineInputBorder(),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: formState.email.isNotEmpty
                            ? Colors.green
                            : Colors.grey,
                      ),
                    ),
                  ),
                  onChanged: (value) => formState.updateEmail(value),
                ),
                isActive: _currentStep >= 1,
              ),
              Step(
                title: const Text('Data de Nascimento'),
                content: InkWell(
                  onTap: () async {
                    DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(1900),
                      lastDate: DateTime.now(),
                    );
                    if (pickedDate != null) {
                      String formattedDate =
                          DateFormat('dd/MM/yyyy').format(pickedDate);
                      formState.updateBirthDate(formattedDate);
                    }
                  },
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                    ),
                    child: Text(formState.birthDate.isEmpty
                        ? 'Selecionar Data de Nascimento'
                        : formState.birthDate),
                  ),
                ),
                isActive: _currentStep >= 2,
              ),
              Step(
                title: const Text('Gênero'),
                content: Column(
                  children: [
                    ListTile(
                      title: const Text('Masculino'),
                      leading: Radio<String>(
                        value: 'Masculino',
                        groupValue: formState.gender,
                        onChanged: (String? value) {
                          formState.updateGender(value!);
                        },
                      ),
                    ),
                    ListTile(
                      title: const Text('Feminino'),
                      leading: Radio<String>(
                        value: 'Feminino',
                        groupValue: formState.gender,
                        onChanged: (String? value) {
                          formState.updateGender(value!);
                        },
                      ),
                    ),
                    ListTile(
                      title: const Text('Outro'),
                      leading: Radio<String>(
                        value: 'Outro',
                        groupValue: formState.gender,
                        onChanged: (String? value) {
                          formState.updateGender(value!);
                        },
                      ),
                    ),
                  ],
                ),
                isActive: _currentStep >= 3,
              ),
              Step(
                title: const Text('Telefone'),
                content: TextFormField(
                  initialValue: formState.phone,
                  decoration: InputDecoration(
                    labelText: 'Telefone',
                    border: OutlineInputBorder(),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: formState.phone.isNotEmpty
                            ? Colors.green
                            : Colors.grey,
                      ),
                    ),
                  ),
                  keyboardType: TextInputType.phone,
                  onChanged: (value) => formState.updatePhone(value),
                ),
                isActive: _currentStep >= 4,
              ),
              Step(
                title: const Text('Termos e Condições'),
                content: Row(
                  children: [
                    Checkbox(
                      value: formState.acceptTerms,
                      onChanged: (bool? value) {
                        formState.updateAcceptTerms(value!);
                      },
                    ),
                    const Text('Aceito os termos e condições.'),
                  ],
                ),
                isActive: _currentStep >= 5,
              ),
            ],
          );
        },
      ),
    );
  }
}
