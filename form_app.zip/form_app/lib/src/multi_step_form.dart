import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'form_state_notifier.dart'; // Certifique-se de que o caminho está correto

class MultiStepFormDemo extends StatefulWidget {
  const MultiStepFormDemo({super.key});

  @override
  _MultiStepFormDemoState createState() => _MultiStepFormDemoState();
}

class _MultiStepFormDemoState extends State<MultiStepFormDemo> {
  int _currentStep = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Formulário Multi-Etapas')),
      body: Consumer<FormStateNotifier>(
        builder: (context, formState, child) {
          return Stepper(
            currentStep: _currentStep,
            onStepContinue: () {
              if (_currentStep < 5) {
                setState(() => _currentStep += 1);
              } else {
                if (formState.acceptTerms) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Formulário Completo!')),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                        content:
                            Text('Por favor, aceite os termos e condições')),
                  );
                }
              }
            },
            onStepCancel: () {
              if (_currentStep > 0) {
                setState(() => _currentStep -= 1);
              }
            },
            steps: [
              Step(
                title: const Text('Nome'),
                content: TextFormField(
                  initialValue: formState.name,
                  decoration: const InputDecoration(labelText: 'Nome'),
                  onChanged: (value) => formState.updateName(value),
                ),
                isActive: _currentStep >= 0,
              ),
              // Adicionar mais etapas conforme necessário
            ],
          );
        },
      ),
    );
  }
}
