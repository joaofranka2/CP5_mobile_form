import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'src/form_state_notifier.dart'; // Certifique-se de que este caminho está correto
import 'src/multi_step_form.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => FormStateNotifier()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Formulário Multi-Etapas',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: const MultiStepFormDemo(),
    );
  }
}
