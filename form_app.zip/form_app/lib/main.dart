import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'src/form_state_notifier.dart';
import 'src/multi_step_form.dart';
import 'src/email_password_form.dart';
import 'src/login_form.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => FormStateNotifier()),
      ],
      child: const FormApp(),
    ),
  );
}

class FormApp extends StatelessWidget {
  const FormApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Formulários - Exemplos',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Formulários - Exemplos')),
      body: ListView(
        children: [
          ListTile(
            title: const Text('Formulário Multi-Etapas'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const MultiStepFormDemo()),
              );
            },
          ),
          ListTile(
            title: const Text('Formulário com Validação de Email e Senha'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const EmailPasswordFormDemo()),
              );
            },
          ),
          ListTile(
            title: const Text('Formulário de Login'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const LoginFormDemo()),
              );
            },
          ),
        ],
      ),
    );
  }
}
