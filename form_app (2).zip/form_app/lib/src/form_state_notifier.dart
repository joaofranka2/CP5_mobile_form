import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class FormStateNotifier with ChangeNotifier {
  List<Map<String, dynamic>> _savedForms = [];

  // Getter para os formulários salvos
  List<Map<String, dynamic>> get savedForms => _savedForms;

  String _name = '';
  String _email = '';
  String _phone = '';
  String _gender = '';
  String _birthDate = '';
  bool _acceptTerms = false;

  // Getters
  String get name => _name;
  String get email => _email;
  String get phone => _phone;
  String get gender => _gender;
  String get birthDate => _birthDate;
  bool get acceptTerms => _acceptTerms;

  // Setters
  void updateName(String value) {
    _name = value;
    notifyListeners();
  }

  void updateEmail(String value) {
    _email = value;
    notifyListeners();
  }

  void updatePhone(String value) {
    _phone = value;
    notifyListeners();
  }

  void updateGender(String value) {
    _gender = value;
    notifyListeners();
  }

  void updateBirthDate(String value) {
    _birthDate = value;
    notifyListeners();
  }

  void updateAcceptTerms(bool value) {
    _acceptTerms = value;
    notifyListeners();
  }

  // Função para salvar os dados do formulário atual como um novo formulário
  Future<void> saveFormData() async {
    final prefs = await SharedPreferences.getInstance();

    // Cria um novo formulário a partir dos dados inseridos
    Map<String, dynamic> newForm = {
      'name': _name,
      'email': _email,
      'phone': _phone,
      'gender': _gender,
      'birthDate': _birthDate,
      'acceptTerms': _acceptTerms,
    };

    // Adiciona o novo formulário à lista de formulários
    _savedForms.add(newForm);

    // Salva a lista de formulários como uma string JSON
    String savedFormsJson = jsonEncode(_savedForms);
    prefs.setString('savedForms', savedFormsJson);

    // Notifica os listeners sobre a mudança de estado
    notifyListeners();
  }

  // Função para resetar os dados do formulário
  void resetForm() {
    _name = '';
    _email = '';
    _phone = '';
    _gender = '';
    _birthDate = '';
    _acceptTerms = false;
    notifyListeners();
  }

  // Carregar os dados salvos
  Future<void> loadFormData() async {
    final prefs = await SharedPreferences.getInstance();
    String? savedFormsJson = prefs.getString('savedForms');

    if (savedFormsJson != null) {
      // Decodifica a string JSON de volta para uma lista de formulários
      _savedForms = List<Map<String, dynamic>>.from(jsonDecode(savedFormsJson));
    }

    notifyListeners();
  }
}
