import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'form_state.dart';

class LoginFormDemo extends StatelessWidget {
  const LoginFormDemo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Formulário de Login')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Consumer<FormStateNotifier>(
          builder: (context, formState, child) {
            return Form(
              child: Column(
                children: [
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Usuário'),
                    initialValue: formState.username,
                    onChanged: (value) {
                      formState.updateUsername(value);
                    },
                  ),
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Senha'),
                    obscureText: true,
                    initialValue: formState.password,
                    onChanged: (value) {
                      formState.updatePassword(value);
                    },
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: formState.isValid
                        ? () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                  content: Text('Login bem-sucedido!')),
                            );
                          }
                        : null,
                    child: const Text('Login'),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
